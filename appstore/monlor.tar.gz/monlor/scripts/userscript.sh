#!/bin/ash
source "$(uci -q get monlor.tools.path)"/scripts/base.sh 
#Start line
